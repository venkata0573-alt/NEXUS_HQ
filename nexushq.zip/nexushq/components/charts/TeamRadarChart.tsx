export { TeamRadarChart } from './index'
